string = input("Enter the string to check for palindrome: ")
def checkPalindrome(String):
    return list(String) == list(reversed(list(String)))

print(checkPalindrome(string))
